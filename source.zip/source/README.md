TrelloStories
=============

TrelloStories is a Chrome Extension to link up with Trello.com to facilitate Story-Task organization in a Scrum Environment.

Logic
=============
Cards concidered Tasks are any cards placed under a list whose title contains the string "(Tasks)" (including parentheses).

Cards which are Stories are those cards NOT placed under Task lists and/or are place within lists whose title contains the string "(Stories)"

Story cards and their task cards are link via 3 digit ID placed at the beginning of the card name. (Ex: 003)
